﻿namespace G4S
{
    internal class EntityBase<T>
    {
    }
}
﻿using AutoMapper;
using G4S.Entities.Pocos;
using G4S.Entities.SearchPocos;

namespace G4S.Models
{
    public class RepairStateChangeSearchModel : SearchModelBase<StateChange>
    {

    }
}

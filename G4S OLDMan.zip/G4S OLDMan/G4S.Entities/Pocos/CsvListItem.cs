﻿using System.Collections.Generic;

namespace G4S.Entities.Pocos
{
    public class CsvListItem : EntityBase
    {
        public string CsvSynonyms{ get; set; }
    }
}

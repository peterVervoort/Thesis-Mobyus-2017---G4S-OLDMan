﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G4S.Entities.Pocos
{
    public class ValidationWarning : EntityBase
    {
        public string Warning { get; set; }
    }
}

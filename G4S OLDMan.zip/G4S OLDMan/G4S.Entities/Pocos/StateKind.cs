﻿using G4S.Entities.Enums;
using System.Collections.Generic;

namespace G4S.Entities.Pocos
{
    public class StateKind : EntityBase
    {
        public string Name { get; set; }
    }
}

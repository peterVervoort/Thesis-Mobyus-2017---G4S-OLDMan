﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace G4S.Entities.Pocos
{
    public class Platform : CsvListItem
    {
        public string PlatformName { get; set; }
    }
}

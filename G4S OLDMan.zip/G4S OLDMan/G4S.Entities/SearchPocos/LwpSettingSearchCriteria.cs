﻿using G4S.Entities.Pocos;

namespace G4S.Entities.SearchPocos
{
    public class LwpSettingSearchCriteria : SearchBase<LwpSetting>
    {
        public string State { get; set; }
    }
}

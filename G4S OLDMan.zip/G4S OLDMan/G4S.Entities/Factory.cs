﻿using Microsoft.Practices.Unity;

namespace G4S.Entities
{
    public class Factory
    {
        public static void Configure(IUnityContainer container)
        {
        }
    }
}

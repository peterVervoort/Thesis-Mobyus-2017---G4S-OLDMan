﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace G4S.Business.Validators.WarningStrings
{
    public static class TranslationWarnings
    {
        public static string GetDoubleInsert() { return " has already been inserted"; }
    }
}

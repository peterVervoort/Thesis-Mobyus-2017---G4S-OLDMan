﻿namespace G4S.DataAccess
{
    public interface IEntityContext
    {
    }
}

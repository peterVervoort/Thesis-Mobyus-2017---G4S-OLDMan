﻿namespace G4S.DataAccess.Enums
{
    internal enum RepositoryAction
    {
        Create,
        Update
    }
}

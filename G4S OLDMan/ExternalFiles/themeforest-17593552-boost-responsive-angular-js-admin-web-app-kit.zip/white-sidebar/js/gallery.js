//MAGNIFIC POPUP
!function ($) {
    "use strict";
    $('.show-image').magnificPopup({type: 'image'});
}(window.jQuery);
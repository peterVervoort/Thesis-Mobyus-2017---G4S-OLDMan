﻿
app.controller("appCtrl", ['$rootScope', '$scope', '$state', '$location', 'Flash','appSettings',
    function ($rootScope, $scope, $state, $location, Flash,appSettings) {


        var vm = this;

        //avalilable themes
        vm.themes = [
            {
                theme: "default",
                icon:"images/c1.jpg"
            },
            {
                theme: "green",
                icon:"images/c2.jpg"
            },
            {
                theme: "gold",
                icon:"images/c3.jpg"
            },
            {
                theme: "red",
                icon:"images/c4.jpg"
            },
            {
                theme: "black",
                icon:"images/c5.jpg"
            },
            {
                theme: "dark",
                icon:"images/c6.jpg"
            },
            {
                theme: "green dark",
                icon:"images/c7.jpg"
            },
            {
                theme: "gold dark",
                icon:"images/c8.jpg"
            },
            {
                theme: "red dark",
                icon: "images/c9.jpg"
            },
            {
                theme: "black dark",
                icon: "images/c10.jpg"
            }
        ];



        //set the theme selected
        vm.setTheme = function (value) {
            $rootScope.theme = value;
        };


        //set the Layout in normal view
        vm.setLayout = function (value) {
            $rootScope.layout = value;
        };

        vm.bodyClasses = 'default';

// this'll be called on every state change in the app
        $scope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams){
            if (angular.isDefined(toState.data.bodyClasses)) {
                vm.bodyClasses = toState.data.bodyClasses;
                return;
            }

            vm.bodyClasses = 'default';
        });

        //Main menu items of the dashboard
        vm.menuItems = [
            {
                title: "Dashboard",
                icon: "th-large",
                state: "",
                sub_itmes: [
                    {title: "dashboard v1", state: "dashboard"},
                    {title: "dashboard v2", state: "dashboard_v2"},
                    {title: "dashboard v3", state: "dashboard_v3"},
                    {title: "dashboard v4", state: "dashboard_v4"},
                    {title: "dashboard v5", state: "dashboard_v5"},
                    {title: "dashboard v6", state: "dashboard_v6"}
                ]
            },
            {
                title: "Widgets",
                icon: "cog",
                state: "widgets"
            },
            {
                title: "Mailbox",
                icon: "envelope",
                state: "",
                sub_itmes: [
                    {title: "inbox", state: "mailbox"},
                    {title: "Email view", state: "mail_detail"},
                    {title: "Compose email", state: "mail_compose"}
                ]
            },
            {
                title: "Graphs",
                icon: "bar-chart",
                state: "",
                sub_itmes: [
                    {title: "Flot charts", state: "flot_charts"},
                    {title: "Morris.js", state: "morris_js"},
                    {title: "Chart.js", state: "chart_js"},
                    {title: "Chartist", state: "chartist"},
                    {title: "Chart Sparkline", state: "chart_sparkline"}
                    //{title: "Pie Charts", state: "pie_charts"}
                ]
            },
            {
                title: "Forms",
                icon: "edit",
                state: "",
                sub_itmes: [
                    {title: "Basic form", state: "form_basic"},
                    {title: "Wizard form", state: "form_wizard"},
                    {title: "Form Masked", state: "form_masked"},
                    {title: "File upload", state: "form_file_upload"},
                    {title: "File Dropzone", state: "file_drop"},
                    {title: "Text editor", state: "form_text_editor"},
                    {title: "Inline edit", state: "form_inline_edit"},
                    {title: "Form Validation", state: "form_validate"},
                    {title: "Tinymce Editor", state: "form_tinymce"},
                    {title: "WYSIHTML5 Editor", state: "form_wysihtml5"}
                ]
            },
            {
                title: "Other Pages",
                icon: "files-o",
                state: "",
                sub_itmes: [
                    {title: "Lockscreen", state: "lockscreen"},
                    {title: "Login", state: "login"},
                    {title: "Register", state: "register"},
                    {title: "404 Page", state: "404"},
                    {title: "Empty page", state: "empty_page"},
                    {title: "gallery", state: "gallery"},
                    {title: "Price tables", state: "price_tables"},
                    {title: "Contact Page", state: "page_contact"}
                ]
            },
            {
                title: "E-commerce",
                icon: "shopping-cart",
                state: "",
                sub_itmes: [
                    {title: "orders", state: "orders"},
                    {title: "order View", state: "order-view"},
                    {title: "Products", state: "products"}
                ]
            },
            {
                title: "Icons",
                icon: "hourglass-o",
                state: "",
                sub_itmes: [
                    {title: "Icons", state: "icons"},
                    {title: "Weather Icon", state: "weather-icon"},
                    {title: "Themify Icons", state: "themifyicons"},
                    {title: "Linea Arrows", state: "linea_arrows"},
                    {title: "Linea Basic", state: "linea_basic"},
                    {title: "Linea Elaboration", state: "linea_elaboration"},
                    {title: "Linea Ecommerce", state: "linea_ecommerce"}
                ]
            },
            {
                title: "UI Elements",
                icon: "flask",
                state: "",
                sub_itmes: [
                    {title: "Typography", state: "typography"},
                    {title: "Buttons", state: "buttons"},
                    {title: "Video", state: "video"},
                    {title: "Panels", state: "tabs_panels"},
                    {title: "Tabs", state: "tabs"},
                    {title: "Alert & notifications", state: "alert_notifications"},
                    {title: "Tree View", state: "tree_view"},
                    {title: "Timeline", state: "timeline"},
                    {title: "Progress Bar", state: "progress_bar"},
                    {title: "Sliders", state: "sliders"},
                    {title: "Range Slider", state: "range_slider"},
                    {title: "Tooltip", state: "tooltip"},
                    {title: "Alert Popup", state: "alert_popup"},
                    {title: "Accordion", state: "accordion"},
                    {title: "Models", state: "models"},
                    {title: "Toastr Alert", state: "toastr_alert"}
                ]
            },
            {
                title: "Grid options",
                icon: "laptop",
                state: "grid_options"
            },
            {
                title: "Tables",
                icon: "table",
                state: "",
                sub_itmes: [
                    {title: "Static Tables", state: "table_basic"},
                    {title: "Data Tables", state: "table_data_tables"},
                    {title: "Responsive Tables", state: "table_responsive"},
                    {title: "Editable Tables", state: "table_editable"},
                    {title: "JSGrid Tables", state: "table_jsgrid"}
                ]
            },
            {
                title: "Users",
                icon: "users",
                state: "",
                sub_itmes: [
                    {title: "profile", state: "user_profile"},
                    {title: "User list", state: "user_list"}
                ]
            },
            {
                title: "maps",
                icon: "map-marker",
                state: "",
                sub_itmes: [
                    {title: "Google maps", state: "google_maps"},
                    {title: "Vector Maps", state: "vector_maps"}
                ]
            },
            {
                title: "Blog",
                icon: "pencil",
                state: "",
                sub_itmes: [
                    {title: "Blog list", state: "blog_list"},
                    {title: "Blog post", state: "blog_post"}
                ]
            },
            {
                title: "Calendar",
                icon: "calendar",
                state: "calendar"
            }
        ];


        //controll sidebar open & close in mobile and normal view



        //navigate to search page
        vm.search = function () {
            $state.go('app.search');
        };




        $(document).ready(function () {
            if ($(this).width() < 769) {
                $('body').addClass('page-small1');
            } else {
                $('body').removeClass('page-small1');
                $('body').removeClass('show-sidebar');
            }

            // MetsiMenu
            //$('#side-menu').metisMenu();

            // Minimalize menu
            $('.navbar-minimalize').click(function () {

                $("body").toggleClass("page-small1");


            });
            $(".nano").nanoScroller();
        });




        (function () {

            $('.fa-search').on('click', function () {
                $('.search').fadeIn(500, function () {
                    $(this).toggleClass('search-toggle');
                });
            });

            $('.search-close').on('click', function () {
                $('.search').fadeOut(500, function () {
                    $(this).removeClass('search-toggle');
                });
            });

        }());


        // Panels
        (function ($) {

            $(function () {
                $('.panel')
                    .on('panel:toggle', function () {
                        var $this,
                            direction;

                        $this = $(this);
                        direction = $this.hasClass('panel-collapsed') ? 'Down' : 'Up';

                        $this.find('.panel-body, .panel-footer')[ 'slide' + direction ](200, function () {
                            $this[ (direction === 'Up' ? 'add' : 'remove') + 'Class' ]('panel-collapsed')
                        });
                    })
                    .on('panel:dismiss', function () {
                        var $this = $(this);

                        if (!!($this.parent('div').attr('class') || '').match(/col-(xs|sm|md|lg)/g) && $this.siblings().length === 0) {
                            $row = $this.closest('.row');
                            $this.parent('div').remove();
                            if ($row.children().length === 0) {
                                $row.remove();
                            }
                        } else {
                            $this.remove();
                        }
                    })
                    .on('click', '[data-panel-toggle]', function (e) {
                        e.preventDefault();
                        $(this).closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '[data-panel-dismiss]', function (e) {
                        e.preventDefault();
                        $(this).closest('.panel').trigger('panel:dismiss');
                    })
                    /* Deprecated */
                    .on('click', '.panel-actions a.fa-caret-up', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this
                            .removeClass('fa-caret-up')
                            .addClass('fa-caret-down');

                        $this.closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '.panel-actions a.fa-caret-down', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this
                            .removeClass('fa-caret-down')
                            .addClass('fa-caret-up');

                        $this.closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '.panel-actions a.fa-times', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this.closest('.panel').trigger('panel:dismiss');
                    });
            });

            $('.ti-settings').on('click', function () {
                $(".adminoption").toggle();
            });
            $('.layout').on('click', function () {
                if($(this).val()=="box")
                {
                    $('body').addClass('box-layout');
                }
                else
                {
                    $('body').removeClass('box-layout');
                }
            });

            $('.menu').on('click', function () {
                $('body').removeClass('normal');
                $('body').removeClass('icon-menu');
                $('body').removeClass('top');
                $('body').addClass($(this).val());

            });
        })(jQuery);

//tooltips
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
            $('[data-toggle="popover"]').popover()
        });


//waves effects
        Waves.attach('.button-wave', ['waves-button', 'waves-light']);
        Waves.init();

        console.log('getting in to the app controller');

    }]);



app.directive('routeCssClassnames', routeCssClassnames);

function routeCssClassnames($rootScope) {
    return {
        restrict: 'A',
        scope: {},
        link: function (scope, elem, attr, ctrl) {

            $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams, fromState, fromParams) {
                var fromClassnames = angular.isDefined(fromState.data) && angular.isDefined(fromState.data.cssClassnames) ? fromState.data.cssClassnames : null;
                var toClassnames = angular.isDefined(toState.data) && angular.isDefined(toState.data.cssClassnames) ? toState.data.cssClassnames : null;

                // don't do anything if they are the same
                if (fromClassnames != toClassnames) {
                    if (fromClassnames) {
                        elem.removeClass(fromClassnames);
                    }

                    if (toClassnames) {
                        elem.addClass(toClassnames);
                    }
                }
            });
        }
    }
}


app.directive('showTab', function () {
    return {
        link: function (scope, element, attrs) {
            element.click(function (e) {
                e.preventDefault();
                jQuery(element).tab('show');
            });
        }
    };
});


app.controller("HomeController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $scope.viewCountOptions = {
            responsive: false
        };
        //vm.showDetails = true;
        vm.home = {};

        vm.home.mainDataLeft = [
            {title: "User Performance", value: "17,50"}
        ];
        vm.home.mainData = [
            {
                title: "New orders",
                value: "580",
                icon: "plus"
            },
            {
                title: "Total sale today",
                value: "$970",
                icon: "shopping-cart"
            },
            {
                title: "Pending Orders",
                value: "256",
                icon: "tasks"
            },
            {
                title: "Total Income",
                value: "$9.7k",
                icon: "usd"
            },
        ];

        $scope.message = "17,50";

        $("#demo-sparkline-area").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
            type: 'line',
            width: '100%',
            height: '40',
            spotRadius: 5,
            lineWidth: 1.5,
            lineColor: 'rgba(255,255,255,.85)',
            fillColor: 'rgba(0,0,0,0.03)',
            spotColor: 'rgba(255,255,255,.5)',
            minSpotColor: 'rgba(255,255,255,.5)',
            maxSpotColor: 'rgba(255,255,255,.5)',
            highlightLineColor: '#ffffff',
            highlightSpotColor: '#ffffff',
            tooltipChartTitle: 'Usage',
            tooltipSuffix: ' %'

        });

        $("#sparkline8").sparkline([5, 6, 7, 2, 0, 4, 2, 4, 5, 7, 2, 4, 12, 14, 4, 2, 14, 12, 7], {
            type: 'bar',
            barWidth: 15,
            height: '150px',
            barColor: '#149957',
            negBarColor: '#40b87b'});
        $(".sparkline8").sparkline([4, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline9").sparkline([3, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline10").sparkline([4, 1], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline11").sparkline([1, 3], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline12").sparkline([3, 5], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline13").sparkline([6, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });

        //moris chart
        $(function () {

            $('#world-map').vectorMap({
                map: 'world_mill_en',
                scaleColors: ['#666', '#29b6d8'],
                normalizeFunction: 'polynomial',
                hoverOpacity: 0.7,
                hoverColor: false,
                focusOn: {
                    x: 0.5,
                    y: 0.5,
                    scale: 1.0
                },
                zoomMin: 0.85,
                markerStyle: {
                    initial: {
                        fill: '#fff',
                        stroke: '#fff',
                        color: '#ffffff'
                    }
                },
                backgroundColor: '#fff',
                regionStyle: {
                    initial: {
                        fill: '#8BC34A',
                        "fill-opacity": 1,
                        stroke: '#87c2e0',
                        "stroke-width": 0,
                        "stroke-opacity": 0
                    },
                    hover: {
                        "fill-opacity": 0.8
                    },
                    selected: {
                        fill: 'yellow'
                    }
                },
                markers: [
                    //http://www.latlong.net/
                    {latLng: [51.507351, -0.127758], name: 'London'},
                    {latLng: [41.385064, 2.173403], name: 'Barcelona'},
                    {latLng: [40.712784, -74.005941], name: 'New York'},
                    {latLng: [-22.911632, -43.188286], name: 'Rio De Janeiro'},
                    {latLng: [49.282729, -123.120738], name: 'Vancuver'},
                    {latLng: [35.689487, 139.691706], name: 'Tokio'},
                    {latLng: [55.755826, 37.617300], name: 'Moskva'},
                    {latLng: [43.214050, 27.914733], name: 'Varna'},
                    {latLng: [30.044420, 31.235712], name: 'Cairo'}
                ]
            });


            var lineData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "#8BC34A",
                        strokeColor: "#FFCA28",
                        pointColor: "#009688",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#FFCA28",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "Example dataset",
                        fillColor: "#FFCA28",
                        strokeColor: "#8BC34A",
                        pointColor: "#F44336",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#009688",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };
            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "#ddd",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);


            var data = [{
                label: "Sales 1",
                data: 21,
                color: "#d3d3d3"
            }, {
                label: "Sales 2",
                data: 3,
                color: "#bababa"
            }, {
                label: "Sales 3",
                data: 15,
                color: "#79d2c0"
            }, {
                label: "Sales 4",
                data: 52,
                color: "#01a8fe"
            }];



        });


        (function () {
            $('#cw-body').fullCalendar({
                contentHeight: 'auto',
                theme: true,
                header: {
                    right: 'next',
                    center: 'title, ',
                    left: 'prev'
                },
                defaultDate: '2014-06-12',
                editable: true,
                events: [
                    {
                        title: 'All Day',
                        start: '2014-06-01',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Long Event',
                        start: '2014-06-07',
                        end: '2014-06-10',
                        className: 'bgm-orange'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-09',
                        className: 'bgm-lightgreen'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-16',
                        className: 'bgm-lightblue'
                    },
                    {
                        title: 'Meet',
                        start: '2014-06-12',
                        end: '2014-06-12',
                        className: 'bgm-green'
                    },
                    {
                        title: 'Lunch',
                        start: '2014-06-12',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Birthday',
                        start: '2014-06-13',
                        className: 'bgm-amber'
                    },
                    {
                        title: 'Google',
                        url: 'http://google.com/',
                        start: '2014-06-28',
                        className: 'bgm-amber'
                    }
                ]
            });
        })();

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);



app.controller("WidgetsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        //vm.showDetails = true;
        vm.home = {};

        !function ($) {
            "use strict";

            $("#spark1").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
                type: 'line',
                width: '100%',
                height: '120',
                spotRadius: 5,
                lineWidth: 1.5,
                lineColor: 'rgba(255,255,255,.85)',
                fillColor: '#FFCA28 ',
                spotColor: 'rgba(255,255,255,.5)',
                minSpotColor: 'rgba(255,255,255,.5)',
                maxSpotColor: 'rgba(255,255,255,.5)',
                highlightLineColor: '#ffffff',
                highlightSpotColor: '#ffffff',
                tooltipChartTitle: 'Usage',
                tooltipSuffix: ' %'

            });

            $("#spark2").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
                type: 'line',
                width: '100%',
                height: '120',
                spotRadius: 5,
                lineWidth: 1.5,
                lineColor: 'rgba(255,255,255,.85)',
                fillColor: '#8BC34A',
                spotColor: 'rgba(255,255,255,.5)',
                minSpotColor: 'rgba(255,255,255,.5)',
                maxSpotColor: 'rgba(255,255,255,.5)',
                highlightLineColor: '#ffffff',
                highlightSpotColor: '#ffffff',
                tooltipChartTitle: 'Usage',
                tooltipSuffix: ' %'

            });


            $("#demo-sparkline-area").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
                type: 'line',
                width: '100%',
                height: '40',
                spotRadius: 5,
                lineWidth: 1.5,
                lineColor: 'rgba(255,255,255,.85)',
                fillColor: 'rgba(0,0,0,0.03)',
                spotColor: 'rgba(255,255,255,.5)',
                minSpotColor: 'rgba(255,255,255,.5)',
                maxSpotColor: 'rgba(255,255,255,.5)',
                highlightLineColor: '#ffffff',
                highlightSpotColor: '#ffffff',
                tooltipChartTitle: 'Usage',
                tooltipSuffix: ' %'

            });

            $("#demo-sparkline-area1").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
                type: 'line',
                width: '100%',
                height: '40',
                spotRadius: 5,
                lineWidth: 1.5,
                lineColor: 'rgba(255,255,255,.85)',
                fillColor: 'rgba(0,0,0,0.03)',
                spotColor: 'rgba(255,255,255,.5)',
                minSpotColor: 'rgba(255,255,255,.5)',
                maxSpotColor: 'rgba(255,255,255,.5)',
                highlightLineColor: '#ffffff',
                highlightSpotColor: '#ffffff',
                tooltipChartTitle: 'Usage',
                tooltipSuffix: ' %'

            });
            $("#sparkline8").sparkline([5, 6, 7, 2, 0, 4, 2, 4, 5, 7, 2, 4, 12, 14, 4, 2, 14, 12, 7], {
                type: 'bar',
                barWidth: 15,
                height: '150px',
                barColor: '#149957',
                negBarColor: '#40b87b'});
            $(".sparkline8").sparkline([4, 2], {
                type: 'pie',
                sliceColors: ['#01a8fe', '#ddd']
            });
            var d1 = [[1262304000000, 6], [1264982400000, 3057], [1267401600000, 20434], [1270080000000, 31982], [1272672000000, 26602], [1275350400000, 27826], [1277942400000, 24302], [1280620800000, 24237], [1283299200000, 21004], [1285891200000, 12144], [1288569600000, 10577], [1291161600000, 10295]];
            var d2 = [[1262304000000, 5], [1264982400000, 200], [1267401600000, 1605], [1270080000000, 6129], [1272672000000, 11643], [1275350400000, 19055], [1277942400000, 30062], [1280620800000, 39197], [1283299200000, 37000], [1285891200000, 27000], [1288569600000, 21000], [1291161600000, 17000]];

            var data1 = [
                {label: "Data 1", data: d1, color: '#17a084'},
                {label: "Data 2", data: d2, color: '#127e68'}
            ];

            $.plot($("#flot-chart1"), data1, {
                xaxis: {
                    tickDecimals: 0
                },
                series: {
                    lines: {
                        show: true,
                        fill: true,
                        fillColor: {
                            colors: [{
                                opacity: 1
                            }, {
                                opacity: 1
                            }]
                        }
                    },
                    points: {
                        width: 0.1,
                        show: false
                    }
                },
                grid: {
                    show: false,
                    borderWidth: 0
                },
                legend: {
                    show: false
                }
            });




            (function () {
                $('#cw-body').fullCalendar({
                    contentHeight: 'auto',
                    theme: true,
                    header: {
                        right: 'next',
                        center: 'title, ',
                        left: 'prev'
                    },
                    defaultDate: '2014-06-12',
                    editable: true,
                    events: [
                        {
                            title: 'All Day',
                            start: '2014-06-01',
                            className: 'bgm-cyan'
                        },
                        {
                            title: 'Long Event',
                            start: '2014-06-07',
                            end: '2014-06-10',
                            className: 'bgm-orange'
                        },
                        {
                            id: 999,
                            title: 'Repeat',
                            start: '2014-06-09',
                            className: 'bgm-lightgreen'
                        },
                        {
                            id: 999,
                            title: 'Repeat',
                            start: '2014-06-16',
                            className: 'bgm-lightblue'
                        },
                        {
                            title: 'Meet',
                            start: '2014-06-12',
                            end: '2014-06-12',
                            className: 'bgm-green'
                        },
                        {
                            title: 'Lunch',
                            start: '2014-06-12',
                            className: 'bgm-cyan'
                        },
                        {
                            title: 'Birthday',
                            start: '2014-06-13',
                            className: 'bgm-amber'
                        },
                        {
                            title: 'Google',
                            url: 'http://google.com/',
                            start: '2014-06-28',
                            className: 'bgm-amber'
                        }
                    ]
                });
            })();
        }(window.jQuery);

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);



app.controller("HomeSixController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        (function () {
            $('#cw-body').fullCalendar({
                contentHeight: 'auto',
                theme: true,
                header: {
                    right: 'next',
                    center: 'title, ',
                    left: 'prev'
                },
                defaultDate: '2014-06-12',
                editable: true,
                events: [
                    {
                        title: 'All Day',
                        start: '2014-06-01',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Long Event',
                        start: '2014-06-07',
                        end: '2014-06-10',
                        className: 'bgm-orange'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-09',
                        className: 'bgm-lightgreen'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-16',
                        className: 'bgm-lightblue'
                    },
                    {
                        title: 'Meet',
                        start: '2014-06-12',
                        end: '2014-06-12',
                        className: 'bgm-green'
                    },
                    {
                        title: 'Lunch',
                        start: '2014-06-12',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Birthday',
                        start: '2014-06-13',
                        className: 'bgm-amber'
                    },
                    {
                        title: 'Google',
                        url: 'http://google.com/',
                        start: '2014-06-28',
                        className: 'bgm-amber'
                    }
                ]
            });
        })();

        $(document).ready(function(){

            $("#sparkline8").sparkline([5, 6, 7, 2, 0, 4, 2, 4, 5, 7, 2, 4, 12, 14, 4, 2, 14, 12, 7], {
                type: 'bar',
                barWidth: 15,
                height: '150px',
                barColor: '#149957',
                negBarColor: '#40b87b'});

            var polarData = [
                {
                    value: 300,
                    color: "#F44336",
                    highlight: "#3d3f4b",
                    label: "App"
                },
                {
                    value: 140,
                    color: "#8BC34A",
                    highlight: "#3d3f4b",
                    label: "Software"
                },
                {
                    value: 200,
                    color: "#FFCA28",
                    highlight: "#3d3f4b",
                    label: "Laptop"
                }
            ];

            var polarOptions = {
                scaleShowLabelBackdrop: true,
                scaleBackdropColor: "rgba(255,255,255,0.75)",
                scaleBeginAtZero: true,
                scaleBackdropPaddingY: 1,
                scaleBackdropPaddingX: 1,
                scaleShowLine: true,
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                animationSteps: 100,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false,
                responsive: true

            };

            var ctx = document.getElementById("polarChart").getContext("2d");
            var myNewChart = new Chart(ctx).PolarArea(polarData, polarOptions);

            /* Make some random data for the Chart*/

            var d1 = [];
            for (var i = 0; i <= 10; i += 1) {
                d1.push([i, parseInt(Math.random() * 30)]);
            }
            var d2 = [];
            for (var i = 0; i <= 25; i += 4) {
                d2.push([i, parseInt(Math.random() * 30)]);
            }
            var d3 = [];
            for (var i = 0; i <= 10; i += 1) {
                d3.push([i, parseInt(Math.random() * 30)]);
            }

            /* Chart Options */

            var options = {
                series: {
                    shadowSize: 0,
                    curvedLines: { //This is a third party plugin to make curved lines
                        apply: true,
                        active: true,
                        monotonicFit: true
                    },
                    lines: {
                        show: false,
                        lineWidth: 0
                    }
                },
                grid: {
                    borderWidth: 0,
                    labelMargin:10,
                    hoverable: true,
                    clickable: true,
                    mouseActiveRadius:6

                },
                xaxis: {
                    tickDecimals: 0,
                    ticks: false
                },

                yaxis: {
                    tickDecimals: 0,
                    ticks: false
                },

                legend: {
                    show: false
                }
            };


            var lineData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "#8BC34A",
                        strokeColor: "#FFCA28",
                        pointColor: "#009688",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#FFCA28",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "Example dataset",
                        fillColor: "#FFCA28",
                        strokeColor: "#8BC34A",
                        pointColor: "#F44336",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#009688",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };
            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "#ddd",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

            /* Let's create the chart */

            if ($("#curved-line-chart")[0]) {
                $.plot($("#curved-line-chart"), [
                    {data: d1, lines: { show: true, fill: 0.98 }, label: 'Product 1', stack: true, color: '#8BC34A' },
                    {data: d3, lines: { show: true, fill: 0.98 }, label: 'Product 2', stack: true, color: '#FFCA28' }
                ], options);
            }

            $('.panel-action-dismiss').click(function(){
                $(this).parent().parent().parent('.panel').parent().remove();
            });

        });

}]);

app.controller("HomeTwoController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        //vm.showDetails = true;
        vm.home = {};

        vm.home.mainDataLeft = [
            {title: "User Performance", value: "17,50"}
        ];
        vm.home.mainData = [
            {
                title: "New orders",
                value: "580",
                icon: "plus"
            },
            {
                title: "Total sale today",
                value: "$970",
                icon: "shopping-cart"
            },
            {
                title: "Pending Orders",
                value: "256",
                icon: "tasks"
            },
            {
                title: "Total Income",
                value: "$9.7k",
                icon: "usd"
            },
        ];

        $("#sparkline8").sparkline([5, 6, 7, 2, 0, 4, 2, 4, 5, 7, 2, 4, 12, 14, 4, 2, 14, 12, 7], {
            type: 'bar',
            barWidth: 15,
            height: '150px',
            barColor: '#149957',
            negBarColor: '#40b87b'});
        $(".sparkline8").sparkline([4, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline9").sparkline([3, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline10").sparkline([4, 1], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline11").sparkline([1, 3], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline12").sparkline([3, 5], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });
        $(".sparkline13").sparkline([6, 2], {
            type: 'pie',
            sliceColors: ['#01a8fe', '#ddd']
        });

        //moris chart
        $(function () {


            if ($('#c-weather')[0]) {
                $.simpleWeather({
                    location: 'Austin, TX',
                    woeid: '',
                    unit: 'f',
                    success: function (weather) {
                        var html = '<div class="cw-current media">' +
                            '<div class="pull-left cwc-icon cwci-' + weather.code + '"></div>' +
                            '<div class="cwc-info media-body">' +
                            '<div class="cwci-temp">' + weather.temp + '&deg;' + weather.units.temp + '</div>' +
                            '<ul class="cwci-info">' +
                            '<li>' + weather.city + ', ' + weather.region + '</li>' +
                            '<li>' + weather.currently + '</li>' +
                            '</ul>' +
                            '</div>' +
                            '</div>' +
                            '<div class="cw-upcoming"></div>';

                        $("#c-weather").html(html);

                        setTimeout(function () {


                            for (i = 0; i < 5; i++) {
                                var l = '<ul class="clearfix">' +
                                    '<li class="m-r-15">' +
                                    '<i class="cwc-icon cwci-sm cwci-' + weather.forecast[i].code + '"></i>' +
                                    '</li>' +
                                    '<li class="cwu-forecast">' + weather.forecast[i].high + '/' + weather.forecast[i].low + '</li>' +
                                    '<li>' + weather.forecast[i].text + '</li>' +
                                    '</ul>';

                                $('.cw-upcoming').append(l);
                            }
                        });
                    },
                    error: function (error) {
                        $("#c-weather").html('<p>' + error + '</p>');
                    }
                });
            }



            var lineData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "#8BC34A",
                        strokeColor: "#FFCA28",
                        pointColor: "#009688",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#FFCA28",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "Example dataset",
                        fillColor: "#FFCA28",
                        strokeColor: "#8BC34A",
                        pointColor: "#F44336",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "#009688",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };
            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "#ddd",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);


            var polarData = [
                {
                    value: 300,
                    color: "#F44336",
                    highlight: "#3d3f4b",
                    label: "App"
                },
                {
                    value: 140,
                    color: "#8BC34A",
                    highlight: "#3d3f4b",
                    label: "Software"
                },
                {
                    value: 200,
                    color: "#FFCA28",
                    highlight: "#3d3f4b",
                    label: "Laptop"
                }
            ];

            var polarOptions = {
                scaleShowLabelBackdrop: true,
                scaleBackdropColor: "rgba(255,255,255,0.75)",
                scaleBeginAtZero: true,
                scaleBackdropPaddingY: 1,
                scaleBackdropPaddingX: 1,
                scaleShowLine: true,
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                animationSteps: 100,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false,
                responsive: true

            };

            var ctx = document.getElementById("polarChart").getContext("2d");
            var myNewChart = new Chart(ctx).PolarArea(polarData, polarOptions);


            var data = [{
                label: "Sales 1",
                data: 21,
                color: "#d3d3d3"
            }, {
                label: "Sales 2",
                data: 3,
                color: "#bababa"
            }, {
                label: "Sales 3",
                data: 15,
                color: "#79d2c0"
            }, {
                label: "Sales 4",
                data: 52,
                color: "#01a8fe"
            }];


        });


        (function () {

            /* Make some random data for the Chart*/

            var d1 = [];
            for (var i = 0; i <= 10; i += 1) {
                d1.push([i, parseInt(Math.random() * 30)]);
            }
            var d2 = [];
            for (var i = 0; i <= 25; i += 4) {
                d2.push([i, parseInt(Math.random() * 30)]);
            }
            var d3 = [];
            for (var i = 0; i <= 10; i += 1) {
                d3.push([i, parseInt(Math.random() * 30)]);
            }

            /* Chart Options */

            var options = {
                series: {
                    shadowSize: 0,
                    curvedLines: { //This is a third party plugin to make curved lines
                        apply: true,
                        active: true,
                        monotonicFit: true
                    },
                    lines: {
                        show: false,
                        lineWidth: 0
                    }
                },
                grid: {
                    borderWidth: 0,
                    labelMargin:10,
                    hoverable: true,
                    clickable: true,
                    mouseActiveRadius:6

                },
                xaxis: {
                    tickDecimals: 0,
                    ticks: false
                },

                yaxis: {
                    tickDecimals: 0,
                    ticks: false
                },

                legend: {
                    show: false
                }
            };

            /* Let's create the chart */

            if ($("#curved-line-chart")[0]) {
                $.plot($("#curved-line-chart"), [
                    {data: d1, lines: { show: true, fill: 0.98 }, label: 'Product 1', stack: true, color: '#8BC34A' },
                    {data: d3, lines: { show: true, fill: 0.98 }, label: 'Product 2', stack: true, color: '#FFCA28' }
                ], options);
            }


            $('#cw-body').fullCalendar({
                contentHeight: 'auto',
                theme: true,
                header: {
                    right: 'next',
                    center: 'title, ',
                    left: 'prev'
                },
                defaultDate: '2014-06-12',
                editable: true,
                events: [
                    {
                        title: 'All Day',
                        start: '2014-06-01',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Long Event',
                        start: '2014-06-07',
                        end: '2014-06-10',
                        className: 'bgm-orange'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-09',
                        className: 'bgm-lightgreen'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-16',
                        className: 'bgm-lightblue'
                    },
                    {
                        title: 'Meet',
                        start: '2014-06-12',
                        end: '2014-06-12',
                        className: 'bgm-green'
                    },
                    {
                        title: 'Lunch',
                        start: '2014-06-12',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Birthday',
                        start: '2014-06-13',
                        className: 'bgm-amber'
                    },
                    {
                        title: 'Google',
                        url: 'http://google.com/',
                        start: '2014-06-28',
                        className: 'bgm-amber'
                    }
                ]
            });
        })();


        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);


app.controller("HomeThreeController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        //vm.showDetails = true;
        vm.home = {};

        vm.home.mainDataLeft = [
            {title: "User Performance", value: "17,50"}
        ];
        vm.home.mainData = [
            {
                title: "New orders",
                value: "580",
                icon: "plus"
            },
            {
                title: "Total sale today",
                value: "$970",
                icon: "shopping-cart"
            },
            {
                title: "Pending Orders",
                value: "256",
                icon: "tasks"
            },
            {
                title: "Total Income",
                value: "$9.7k",
                icon: "usd"
            },
        ];

        vm.home.orderData = [
            {
                id: '0001',
                purchage_date: '03/11/2015',
                client_name: 'Addison Nichols',
                amount: '515.20',
                quantity: '547',
                shipment: '04/10/2015',
                status: 'Standby'
            },
            {
                id: '0002',
                purchage_date: '05/11/2015',
                client_name: 'Albert Watkins',
                amount: '22.30',
                quantity: '122',
                shipment: '06/10/2015',
                status: 'Paid'
            },
            {
                id: '0003',
                purchage_date: '07/09/2015',
                client_name: 'Johnny Fernandez',
                amount: '31.4',
                quantity: '68',
                shipment: '28/09/2015',
                status: 'Standby'
            },
            {
                id: '0011',
                purchage_date: '19/09/2015',
                client_name: 'Gilbert Edwards',
                amount: '5115.12',
                quantity: '51',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0012',
                purchage_date: '20/09/2015',
                client_name: 'Norman Hill',
                amount: '5124.13',
                quantity: '41',
                shipment: '-',
                status: 'Shipped'
            },
            {
                id: '0013',
                purchage_date: '22/09/2015',
                client_name: 'Samantha Murphy',
                amount: '513.214',
                quantity: '54',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0014',
                purchage_date: '30/09/2015',
                client_name: 'Nora Lambert',
                amount: '147.15',
                quantity: '65',
                shipment: '23/11/2015',
                status: 'Paid'
            },
            {
                id: '0015',
                purchage_date: '29/07/2015',
                client_name: 'Shelly Robertson',
                amount: '15.016',
                quantity: '12',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0016',
                purchage_date: '22/07/2015',
                client_name: 'Everett Garcia',
                amount: '188.19',
                quantity: '65',
                shipment: '029/11/2015',
                status: 'Paid'
            }
        ];



        $scope.whatClassIsIt = function (someValue) {
            if (someValue == "Paid")
                return "label-success"
            else if (someValue == "Shipped")
                return "label-purple";
            else if (someValue == "Rejected")
                return "label-danger";
            else if (someValue == "Canceled")
                return "label-inverse";
            else if (someValue == "Standby")
                return "label-info";
        }



        $("#demo-sparkline-area").sparkline([57, 69, 70, 62, 73, 79, 76, 77, 73, 52, 57, 50, 60, 55, 70, 68], {
            type: 'line',
            width: '100%',
            height: '40',
            spotRadius: 5,
            lineWidth: 1.5,
            lineColor: 'rgba(255,255,255,.85)',
            fillColor: 'rgba(0,0,0,0.03)',
            spotColor: 'rgba(255,255,255,.5)',
            minSpotColor: 'rgba(255,255,255,.5)',
            maxSpotColor: 'rgba(255,255,255,.5)',
            highlightLineColor: '#ffffff',
            highlightSpotColor: '#ffffff',
            tooltipChartTitle: 'Usage',
            tooltipSuffix: ' %'

        });


        var d1 = [[1262304000000, 6], [1264982400000, 3057], [1267401600000, 20434], [1270080000000, 31982], [1272672000000, 26602], [1275350400000, 27826], [1277942400000, 24302], [1280620800000, 24237], [1283299200000, 21004], [1285891200000, 12144], [1288569600000, 10577], [1291161600000, 10295]];
        var d2 = [[1262304000000, 5], [1264982400000, 200], [1267401600000, 1605], [1270080000000, 6129], [1272672000000, 11643], [1275350400000, 19055], [1277942400000, 30062], [1280620800000, 39197], [1283299200000, 37000], [1285891200000, 27000], [1288569600000, 21000], [1291161600000, 17000]];

        var data1 = [
            { label: "Data 1", data: d1, color: '#17a084'},
            { label: "Data 2", data: d2, color: '#127e68' }
        ];

        $.plot($("#flot-chart1"), data1, {
            xaxis: {
                tickDecimals: 0
            },
            series: {
                lines: {
                    show: true,
                    fill: true,
                    fillColor: {
                        colors: [{
                            opacity: 1
                        }, {
                            opacity: 1
                        }]
                    }
                },
                points: {
                    width: 0.1,
                    show: false
                }
            },
            grid: {
                show: false,
                borderWidth: 0
            },
            legend: {
                show: false
            }
        });




        (function () {
            $('#cw-body').fullCalendar({
                contentHeight: 'auto',
                theme: true,
                header: {
                    right: 'next',
                    center: 'title, ',
                    left: 'prev'
                },
                defaultDate: '2014-06-12',
                editable: true,
                events: [
                    {
                        title: 'All Day',
                        start: '2014-06-01',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Long Event',
                        start: '2014-06-07',
                        end: '2014-06-10',
                        className: 'bgm-orange'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-09',
                        className: 'bgm-lightgreen'
                    },
                    {
                        id: 999,
                        title: 'Repeat',
                        start: '2014-06-16',
                        className: 'bgm-lightblue'
                    },
                    {
                        title: 'Meet',
                        start: '2014-06-12',
                        end: '2014-06-12',
                        className: 'bgm-green'
                    },
                    {
                        title: 'Lunch',
                        start: '2014-06-12',
                        className: 'bgm-cyan'
                    },
                    {
                        title: 'Birthday',
                        start: '2014-06-13',
                        className: 'bgm-amber'
                    },
                    {
                        title: 'Google',
                        url: 'http://google.com/',
                        start: '2014-06-28',
                        className: 'bgm-amber'
                    }
                ]
            });
        })();

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);


app.controller("HomeFourController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        //vm.showDetails = true;
        vm.home = {};

        vm.home.mainData = [
            {
                title: "User Performance",
                value: "17,50",
                percent: "60",
                progress: 'p4-bg'
            },
            {
                title: "Users Activity",
                value: "210",
                percent: "85",
                progress: 'p3-bg'
            },
            {
                title: "HDD Usage",
                value: "50GB",
                percent: "50",
                progress: 'p2-bg'
            },
            {
                title: "Pending Orders",
                value: "256",
                percent: "50",
                progress: 'p1-bg'
            },
        ];

        vm.home.orderData = [
            {
                id: '0001',
                purchage_date: '03/11/2015',
                client_name: 'Addison Nichols',
                amount: '515.20',
                quantity: '547',
                shipment: '04/10/2015',
                status: 'Standby'
            },
            {
                id: '0002',
                purchage_date: '05/11/2015',
                client_name: 'Albert Watkins',
                amount: '22.30',
                quantity: '122',
                shipment: '06/10/2015',
                status: 'Paid'
            },
            {
                id: '0003',
                purchage_date: '07/09/2015',
                client_name: 'Johnny Fernandez',
                amount: '31.4',
                quantity: '68',
                shipment: '28/09/2015',
                status: 'Standby'
            },
            {
                id: '0011',
                purchage_date: '19/09/2015',
                client_name: 'Gilbert Edwards',
                amount: '5115.12',
                quantity: '51',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0012',
                purchage_date: '20/09/2015',
                client_name: 'Norman Hill',
                amount: '5124.13',
                quantity: '41',
                shipment: '-',
                status: 'Shipped'
            },
            {
                id: '0013',
                purchage_date: '22/09/2015',
                client_name: 'Samantha Murphy',
                amount: '513.214',
                quantity: '54',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0014',
                purchage_date: '30/09/2015',
                client_name: 'Nora Lambert',
                amount: '147.15',
                quantity: '65',
                shipment: '23/11/2015',
                status: 'Paid'
            },
            {
                id: '0015',
                purchage_date: '29/07/2015',
                client_name: 'Shelly Robertson',
                amount: '15.016',
                quantity: '12',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0016',
                purchage_date: '22/07/2015',
                client_name: 'Everett Garcia',
                amount: '188.19',
                quantity: '65',
                shipment: '029/11/2015',
                status: 'Paid'
            }
        ];



        $scope.whatClassIsIt = function (someValue) {
            if (someValue == "Paid")
                return "label-success"
            else if (someValue == "Shipped")
                return "label-purple";
            else if (someValue == "Rejected")
                return "label-danger";
            else if (someValue == "Canceled")
                return "label-inverse";
            else if (someValue == "Standby")
                return "label-info";
        }

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);


app.controller("AlertController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        document.querySelector('.timer-alert').onclick = function () {
            swal({
                title: "Auto close alert!",
                text: "I will close in 3 seconds.",
                timer: 3000,
                showConfirmButton: false
            });
        };
        document.querySelector('.success-alert').onclick = function () {
            swal("Good job!", "You clicked the button!", "success");
        };
        document.querySelector('.simple-alert').onclick = function () {
            swal({
                title: "Welcome in Alerts",
                text: "Lorem Ipsum is simply dummy text of the printing and typesetting industry."
            });
        };
        document.querySelector('.warning-alert').onclick = function () {
            swal({
                    title: "Are you sure?",
                    text: "You will not be able to recover this imaginary file!",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonColor: '#DD6B55',
                    confirmButtonText: 'Yes, delete it!',
                    closeOnConfirm: false
                },
                function () {
                    swal("Deleted!", "Your imaginary file has been deleted!", "success");
                });
        };

        //tooltips
        $(function () {
            $('[data-toggle="tooltip"]').tooltip();
            $('[data-toggle="popover"]').popover()
        });

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);


app.controller("CalendarController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        $(function () {
            /* initialize the external events
             -----------------------------------------------------------------*/

            $('#external-events .fc-event').each(function () {

                // store data so the calendar knows to render an event upon drop
                $(this).data('event', {
                    title: $.trim($(this).text()), // use the element's text as the event title
                    stick: true // maintain when user navigates (see docs on the renderEvent method)
                });

                // make the event draggable using jQuery UI
                $(this).draggable({
                    zIndex: 999,
                    revert: true, // will cause the event to go back to its
                    revertDuration: 0  //  original position after the drag
                });

            });


            /* initialize the calendar
             -----------------------------------------------------------------*/

            $('#calendar').fullCalendar({
                events: [
                    {
                        title: 'All Day Event',
                        start: '2015-09-05'
                    },
                    {
                        title: 'Meeting',
                        start: '2015-09-14T10:30:00',
                        end: '2015-02-12T12:30:00'

                    },
                    {
                        title: 'Conference',
                        start: '2015-09-19'
                    },
                    {
                        title: 'Birthday party',
                        start: '2015-09-20'
                    }
                ],
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                editable: true,
                droppable: true, // this allows things to be dropped onto the calendar
                drop: function () {
                    // is the "remove after drop" checkbox checked?
                    if ($('#drop-remove').is(':checked')) {
                        // if so, remove the element from the "Draggable Events" list
                        $(this).remove();
                    }
                }

            });


        });





    }]);

app.controller("ChartController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        !function($) {
            "use strict";

            var lineData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "Example dataset",
                        fillColor: "rgba(66,220,141,0.5)",
                        strokeColor: "rgba(66,220,141,1)",
                        pointColor: "rgba(66,220,141,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(66,220,141,1)",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "Example dataset",
                        fillColor: "rgba(20,153,87,0.5)",
                        strokeColor: "rgba(20,153,87,0.7)",
                        pointColor: "rgba(20,153,87,1)",
                        pointStrokeColor: "#fff",
                        pointHighlightFill: "#fff",
                        pointHighlightStroke: "rgba(20,153,87,1)",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };

            var lineOptions = {
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(255,255,255,.05)",
                scaleGridLineWidth: 1,
                bezierCurve: true,
                bezierCurveTension: 0.4,
                pointDot: true,
                pointDotRadius: 4,
                pointDotStrokeWidth: 1,
                pointHitDetectionRadius: 20,
                datasetStroke: true,
                datasetStrokeWidth: 2,
                datasetFill: true,
                responsive: true,
                scaleFontColor:'#949ba2'
            };


            var ctx = document.getElementById("lineChart").getContext("2d");
            var myNewChart = new Chart(ctx).Line(lineData, lineOptions);

            var barData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "My First dataset",
                        fillColor: "rgba(66,220,141,0.5)",
                        strokeColor: "rgba(66,220,141,0.8)",
                        highlightFill: "rgba(66,220,141,0.75)",
                        highlightStroke: "rgba(66,220,141,1)",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "My Second dataset",
                        fillColor: "rgba(20,153,87,0.5)",
                        strokeColor: "rgba(20,153,87,0.8)",
                        highlightFill: "rgba(20,153,87,0.75)",
                        highlightStroke: "rgba(20,153,87,1)",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };

            var barOptions = {
                scaleBeginAtZero: true,
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(255,255,255,.05)",
                scaleGridLineWidth: 1,
                barShowStroke: true,
                barStrokeWidth: 2,
                barValueSpacing: 5,
                barDatasetSpacing: 1,
                responsive: true,
                scaleFontColor:'#949ba2'
            };


            var ctx = document.getElementById("barChart").getContext("2d");
            var myNewChart = new Chart(ctx).Bar(barData, barOptions);

            var polarData = [
                {
                    value: 300,
                    color: "#149957",
                    highlight: "#149957",
                    label: "App"
                },
                {
                    value: 140,
                    color: "#65f2aa",
                    highlight: "#149957",
                    label: "Software"
                },
                {
                    value: 200,
                    color: "#59eca1",
                    highlight: "#149957",
                    label: "Laptop"
                }
            ];

            var polarOptions = {
                scaleShowLabelBackdrop: true,
                scaleBackdropColor: "rgba(255,255,255,0.75)",
                scaleBeginAtZero: true,
                scaleBackdropPaddingY: 1,
                scaleBackdropPaddingX: 1,
                scaleShowLine: true,
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                animationSteps: 100,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false,
                responsive: true

            };

            var ctx = document.getElementById("polarChart").getContext("2d");
            var myNewChart = new Chart(ctx).PolarArea(polarData, polarOptions);

            var doughnutData = [
                {
                    value: 300,
                    color: "#149957",
                    highlight: "#149957",
                    label: "App"
                },
                {
                    value: 50,
                    color: "#65f2aa",
                    highlight: "#149957",
                    label: "Software"
                },
                {
                    value: 100,
                    color: "#65f2aa",
                    highlight: "#149957",
                    label: "Laptop"
                }
            ];

            var doughnutOptions = {
                segmentShowStroke: true,
                segmentStrokeColor: "#fff",
                segmentStrokeWidth: 2,
                percentageInnerCutout: 45, // This is 0 for Pie charts
                animationSteps: 100,
                animationEasing: "easeOutBounce",
                animateRotate: true,
                animateScale: false,
                responsive: true
            };


            var ctx = document.getElementById("doughnutChart").getContext("2d");
            var myNewChart = new Chart(ctx).Doughnut(doughnutData, doughnutOptions);


        }(window.jQuery);

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);


app.controller("SparkLineController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        $(function () {
            $("#sparkline1").sparkline([52, 12, 44], {
                type: 'pie',
                height: '180px',
                sliceColors: ['#149957', '#2cbb74', '#4dde96']});
            $("#sparkline2").sparkline([5, 6, 7, 2, 0, 4, 2, 4, 5, 7, 2, 4, 12, 14, 4, 2, 14, 12, 7], {
                type: 'bar',
                barWidth:10,
                height: '180px',
                barColor: '#149957',
                negBarColor: '#c6c6c6'});
            $("#sparkline3").sparkline([34, 43, 43, 35, 44, 32, 15, 22, 46, 33, 86, 54, 73, 53, 12, 53, 23, 65, 23, 63, 53, 42, 34, 56, 76, 15, 54, 23, 44], {
                type: 'line',
                lineWidth: 1,
                height: '180px',
                lineColor: '#149957',
                fillColor: 'rgba(68, 70, 79, 0.0)'
            });
        });


        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);


app.controller("FileDropController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(".dropzone").dropzone({ url: "/file-upload" });
    }]);



app.controller("ChartlistController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(function () {
            $('.panel-action-dismiss').click(function(){
                $(this).parent().parent().parent('.panel').parent().remove();
            });

// horizontal bar
            new Chartist.Bar('#ct-chart4', {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
                series: [
                    [5, 4, 3, 7, 5, 10, 3],
                    [3, 2, 9, 5, 4, 6, 4]
                ]
            }, {
                seriesBarDistance: 10,
                reverseData: true,
                horizontalBars: true,
                axisY: {
                    offset: 70
                }
            });

// Stocked bar chart

            new Chartist.Bar('#ct-chart3', {
                labels: ['Q1', 'Q2', 'Q3', 'Q4'],
                series: [
                    [800000, 1200000, 1400000, 1300000],
                    [200000, 400000, 500000, 300000],
                    [100000, 200000, 400000, 600000]
                ]
            }, {
                stackBars: true,
                axisY: {
                    labelInterpolationFnc: function (value) {
                        return (value / 1000) + 'k';
                    }
                }
            }).on('draw', function (data) {
                    if (data.type === 'bar') {
                        data.element.attr({
                            style: 'stroke-width: 30px'
                        });
                    }
                });

            // Simple line

            new Chartist.Line('#ct-chart1', {
                labels: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'],
                series: [
                    [12, 9, 7, 8, 5],
                    [2, 1, 3.5, 7, 3],
                    [1, 3, 4, 5, 6]
                ]
            }, {
                fullWidth: true,
                chartPadding: {
                    right: 40
                }
            });

            // Simple pie chart

            var data = {
                series: [5, 3, 4]
            };

            var sum = function (a, b) {
                return a + b
            };

            /*new Chartist.Pie('#ct-chart5', data, {
             labelInterpolationFnc: function (value) {
             return Math.round(value / data.series.reduce(sum) * 100) + '%';
             }
             });*/

            // Gauge chart

            new Chartist.Pie('#ct-chart6', {
                series: [20, 10, 30, 40]
            }, {
                donut: true,
                donutWidth: 60,
                startAngle: 270,
                total: 200,
                showLabel: false
            });

        });


    }]);



app.controller("FlotChartController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        !function($) {
            "use strict";
//Flot Bar Chart
            $(function () {
                var barOptions = {
                    series: {
                        bars: {
                            show: true,
                            barWidth: 0.3,
                            fill: true,
                            fillColor: {
                                colors: [{
                                    opacity: 0.8
                                }, {
                                    opacity: 0.8
                                }]
                            }
                        }
                    },
                    yaxis: {
                        tickColor : '#transparent',
                        tickLength: 0,
                        font: {
                            color: '#949ba2'
                        }
                    },
                    xaxis: {
                        tickColor : '#transparent',
                        tickLength: 0,
                        font: {
                            color: '#949ba2'
                        }
                    },
                    colors: ["#149957"],
                    grid: {
                        color: "#999999",
                        hoverable: true,
                        clickable: true,
                        tickColor: " #949ba2",
                        borderWidth: 0
                    },
                    legend: {
                        show: false

                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "x: %x, y: %y"
                    }
                };
                var barData = {
                    label: "bar",
                    data: [
                        [1, 34],
                        [2, 25],
                        [3, 19],
                        [4, 34],
                        [5, 32],
                        [6, 44]
                    ]
                };

                $.plot($("#flot-bar-chart"), [barData], barOptions);

            });

            $(function () {
                var barOptions = {
                    series: {
                        lines: {
                            show: true,
                            lineWidth: 2,
                            fill: true,
                            fillColor: {
                                colors: [{
                                    opacity: 0.0
                                }, {
                                    opacity: 0.0
                                }]
                            }
                        }
                    },
                    colors: ["#149957"],
                    grid: {
                        color: "#999999",
                        hoverable: true,
                        clickable: true,
                        tickColor: "#949ba2",
                        borderWidth: 0
                    },
                    legend: {
                        show: false
                    },
                    yaxis: {
                        tickColor : '#transparent',
                        tickLength: 0,
                        font: {
                            color: '#949ba2'
                        }
                    },
                    xaxis: {
                        tickColor : '#transparent',
                        tickLength: 0,
                        font: {
                            color: '#949ba2'
                        }
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "x: %x, y: %y"
                    }
                };
                var barData = {
                    label: "bar",
                    data: [
                        [1, 34],
                        [2, 25],
                        [3, 19],
                        [4, 34],
                        [5, 32],
                        [6, 44]
                    ]
                };
                $.plot($("#flot-line-chart"), [barData], barOptions);

            });
//Flot Pie Chart
            $(function () {

                var data = [{
                    label: "Sales 1",
                    data: 21,
                    color: "#5edf9f"
                }, {
                    label: "Sales 2",
                    data: 3,
                    color: "#44d58d"
                }, {
                    label: "Sales 3",
                    data: 15,
                    color: "#3ec280"
                }, {
                    label: "Sales 4",
                    data: 52,
                    color: "#149957"
                }];

                var plotObj = $.plot($("#flot-pie-chart"), data, {
                    series: {
                        pie: {
                            show: true
                        }
                    },
                    grid: {
                        hoverable: true
                    },
                    tooltip: true,
                    tooltipOpts: {
                        content: "%p.0%, %s", // show percentages, rounding to 2 decimal places
                        shifts: {
                            x: 20,
                            y: 0
                        },
                        defaultTheme: false
                    }
                });

            });

            $(function () {

                var container = $("#flot-line-chart-moving");

                // Determine how many data points to keep based on the placeholder's initial size;
                // this gives us a nice high-res plot while avoiding more than one point per pixel.

                var maximum = container.outerWidth() / 2 || 300;

                //

                var data = [];

                function getRandomData() {

                    if (data.length) {
                        data = data.slice(1);
                    }

                    while (data.length < maximum) {
                        var previous = data.length ? data[data.length - 1] : 50;
                        var y = previous + Math.random() * 10 - 5;
                        data.push(y < 0 ? 0 : y > 100 ? 100 : y);
                    }

                    // zip the generated y values with the x values

                    var res = [];

                    for (var i = 0; i < data.length; ++i) {
                        res.push([i, data[i]]);
                    }

                    return res;
                }
                var series = [];
                series = [{
                    data: getRandomData(),
                    lines: {
                        fill: true
                    }
                }];


                var plot = $.plot(container, series, {
                    grid: {
                        color: "#999999",
                        tickColor: "#ddd",
                        borderWidth: 0,
                        minBorderMargin: 20,
                        labelMargin: 10,
                        backgroundColor: {
                            colors: ["#fff", "#fff"]
                        },
                        margin: {
                            top: 8,
                            bottom: 20,
                            left: 20
                        },

                        markings: function (axes) {
                            var markings = [];
                            var xaxis = axes.xaxis;
                            for (var x = Math.floor(xaxis.min); x < xaxis.max; x += xaxis.tickSize * 2) {
                                markings.push({
                                    xaxis: {
                                        from: x,
                                        to: x + xaxis.tickSize
                                    },
                                    color: "#fff"
                                });
                            }
                            return markings;
                        }
                    },
                    colors: ["#149957"],
                    xaxis: {
                        font: {
                            color: '#949ba2'
                        },
                        tickFormatter: function () {
                            return "";

                        }
                    },
                    yaxis: {
                        font: {
                            color: '#949ba2'
                        },
                        min: 0,
                        max: 110
                    },
                    legend: {
                        show: true
                    }
                });

                // Update the random dataset at 25FPS for a smoothly-animating chart

                setInterval(function updateRandom() {
                    series[0].data = getRandomData();
                    plot.setData(series);
                    plot.draw();
                }, 40);

            });

        }(window.jQuery);
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("FormAdvancedController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

        $(function () {

            //------------- Fancy select -------------//
            $('.fancy-select').fancySelect();
            //custom templating
            $('.fancy-select1').fancySelect({
                optionTemplate: function (optionEl) {
                    return optionEl.text() + '<i class="pull-left ' + optionEl.data('icon') + '"></i>';
                }
            });

            //------------- Select 2 -------------//
            $('.select2').select2({placeholder: 'Select state'});

            //minumum 2 symbols input
            $('.select2-minimum').select2({
                placeholder: 'Select state',
                minimumInputLength: 2
            });

            // BOOTSTRAP SLIDER CTRL
            $('[data-ui-slider]').slider();
            // MASKED
            $('[data-masked]').inputmask();

        });
    }]);


app.controller("FormBasicController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);


app.controller("FileUploadController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
// Upload Demo
// -----------------------------------

        (function(window, document, $, undefined){

            $(function () {
                'use strict';

                // Initialize the jQuery File Upload widget:
                $('#fileupload').fileupload({
                    // Uncomment the following to send cross-domain cookies:
                    //xhrFields: {withCredentials: true},
                    // url: 'server/upload'
                });

                // Enable iframe cross-domain access via redirect option:
                $('#fileupload').fileupload(
                    'option',
                    'redirect',
                    window.location.href.replace(
                        /\/[^\/]*$/,
                        '/cors/result.html?%s'
                    )
                );

                // Load existing files:
                $('#fileupload').addClass('fileupload-processing');
                $.ajax({
                    // Uncomment the following to send cross-domain cookies:
                    //xhrFields: {withCredentials: true},
                    url: $('#fileupload').fileupload('option', 'url'),
                    dataType: 'json',
                    context: $('#fileupload')[0]
                }).always(function () {
                    $(this).removeClass('fileupload-processing');
                }).done(function (result) {
                    $(this).fileupload('option', 'done')
                        .call(this, $.Event('done'), {result: result});
                });

            });

        })(window, document, window.jQuery);
    }]);


app.controller("FormInlineEditController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        // Xeditable Demo
// -----------------------------------

        (function(window, document, $, undefined){

            $(function(){

                // Font Awesome support
                $.fn.editableform.buttons =
                    '<button type="submit" class="btn btn-primary btn-sm editable-submit">'+
                    '<i class="fa fa-fw fa-check"></i>'+
                    '</button>'+
                    '<button type="button" class="btn btn-default btn-sm editable-cancel">'+
                    '<i class="fa fa-fw fa-times"></i>'+
                    '</button>';

                //defaults
//       $.fn.editable.defaults.url = '../server/xeditable.res';

                //enable / disable
                $('#enable').click(function() {
                    $('#user .editable').editable('toggleDisabled');
                });

                //editables
                $('#username').editable({
//               url: '../server/xeditable.res',
                    type: 'text',
                    pk: 1,
                    name: 'username',
                    title: 'Enter username'
                });

                $('#firstname').editable({
                    validate: function(value) {
                        if($.trim(value) === '') return 'This field is required';
                    }
                });

                $('#sex').editable({
                    prepend: "not selected",
                    source: [
                        {value: 1, text: 'Male'},
                        {value: 2, text: 'Female'}
                    ],
                    display: function(value, sourceData) {
                        var colors = {"": "gray", 1: "green", 2: "blue"},
                            elem = $.grep(sourceData, function(o){return o.value == value;});

                        if(elem.length) {
                            $(this).text(elem[0].text).css("color", colors[value]);
                        } else {
                            $(this).empty();
                        }
                    }
                });

                $('#status').editable();

                $('#group').editable({
                    showbuttons: false
                });

                $('#dob').editable();

                $('#event').editable({
                    placement: 'right',
                    combodate: {
                        firstItem: 'name'
                    }
                });

                $('#comments').editable({
                    showbuttons: 'bottom'
                });

                $('#note').editable();
                $('#pencil').click(function(e) {
                    e.stopPropagation();
                    e.preventDefault();
                    $('#note').editable('toggle');
                });

                $('#fruits').editable({
                    pk: 1,
                    limit: 3,
                    source: [
                        {value: 1, text: 'banana'},
                        {value: 2, text: 'peach'},
                        {value: 3, text: 'apple'},
                        {value: 4, text: 'watermelon'},
                        {value: 5, text: 'orange'}
                    ]
                });

                $('#user .editable').on('hidden', function(e, reason){
                    if(reason === 'save' || reason === 'nochange') {
                        var $next = $(this).closest('tr').next().find('.editable');
                        if($('#autoopen').is(':checked')) {
                            setTimeout(function() {
                                $next.editable('show');
                            }, 300);
                        } else {
                            $next.focus();
                        }
                    }
                });

                // TABLE
                // -----------------------------------

                $('#users a').editable({
                    type: 'text',
                    name: 'username',
                    title: 'Enter username'
                });

            });

        })(window, document, window.jQuery);


    }]);


app.controller("FormMaskedController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(function(){
            $("#product").mask("99/99/9999",{placeholder:" "});
            $("#date").mask("99/99/9999",{placeholder:"mm/dd/yyyy"});
            $("#phone").mask("(999) 999-9999");
            $("#tin").mask("99-9999999");
            $("#ssn").mask("999-99-9999");
            $('#phoneext').mask("(999) 999-9999? x99999");

            $.mask.definitions['~']='[+-]';
            $("#eyescript").mask("~9.99 ~9.99 999");
        });

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);


app.controller("FormTextEditorController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

        $(document).ready(function () {

            $('.summernote').summernote();

        });
        var edit = function () {
            $('.click2edit').summernote({focus: true});
        };
        var save = function () {
            var aHTML = $('.click2edit').code(); //save HTML If you need(aHTML: array).
            $('.click2edit').destroy();
        };
    }]);



app.controller("FormValidateController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);


app.controller("FormWizardController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

        //------------- forms-wizard.js -------------//
        $(document).ready(function() {

            //------------- Sparklines in header stats -------------//
            $('#spark-visitors').sparkline([5,8,10,8,7,12,11,6,13,8,5,8,10,11,7,12,11,6,13,8], {
                type: 'bar',
                width: '100%',
                height: '20px',
                barColor: '#dfe2e7',
                zeroAxis: false,
            });

            $('#spark-templateviews').sparkline([12,11,6,13,8,5,8,10,12,11,6,13,8,5,8,10,12,11,6,13,8,5,8], {
                type: 'bar',
                width: '100%',
                height: '20px',
                barColor: '#dfe2e7',
                zeroAxis: false,
            });

            $('#spark-sales').sparkline([19,18,20,17,20,18,22,24,23,19,18,20,17,20,18,22,24,23,19,18,20,17], {
                type: 'bar',
                width: '100%',
                height: '20px',
                barColor: '#dfe2e7',
                zeroAxis: false,
            });

            //------------- Form wizard -------------//

            //add validation to wizard
            var $validator = $("#wizard form").validate({
                errorPlacement: function( error, element ) {
                    var place = element.closest('.input-group');
                    if (!place.get(0)) {
                        place = element;
                    }
                    if (place.get(0).type === 'checkbox') {
                        place = element.parent();
                    }
                    if (error.text() !== '') {
                        place.after(error);
                    }
                },
                errorClass: 'help-block',
                rules: {
                    firstname: {
                        required: true
                    },
                    email: {
                        required: true,
                        email: true
                    },
                    username: {
                        required: true
                    },
                    password: {
                        required: true,
                        minlength: 5
                    },
                    password_2: {
                        required: true,
                        minlength: 5,
                        equalTo: "#password"
                    }
                },
                messages: {
                    firstname: {
                        required: "Required"
                    },
                    email: {
                        required: "Required"
                    }
                },
                highlight: function( label ) {
                    $(label).closest('.form-group').removeClass('has-success').addClass('has-error');
                },
                success: function( label ) {
                    $(label).closest('.form-group').removeClass('has-error');
                    label.remove();
                }
            });

            //init first wizard
            $('#wizard').bootstrapWizard({
                tabClass: 'bwizard-steps',
                nextSelector: 'ul.pager li.next',
                previousSelector: 'ul.pager li.previous',
                firstSelector: null,
                lastSelector: null,
                onNext: function( tab, navigation, index, newindex ) {
                    var validated = $('#wizard form').valid();
                    if( !validated ) {
                        $validator.focusInvalid();
                        return false;
                    }
                },
                onTabClick: function( tab, navigation, index, newindex ) {
                    if ( newindex == index + 1 ) {
                        return this.onNext( tab, navigation, index, newindex);
                    } else if ( newindex > index + 1 ) {
                        return false;
                    } else {
                        return true;
                    }
                },
                onTabShow: function( tab, navigation, index ) {
                    tab.prevAll().addClass('completed');
                    tab.nextAll().removeClass('completed');
                    var $total = navigation.find('li').length;
                    var $current = index+1;
                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $('#wizard').find('.pager .next').hide();
                        $('#wizard').find('.pager .finish').show();
                        $('#wizard').find('.pager .finish').removeClass('disabled');
                    } else {
                        $('#wizard').find('.pager .next').show();
                        $('#wizard').find('.pager .finish').hide();
                    }
                }
            });

            //wizard is finish
            $('#wizard .finish').click(function() {
                //show message
            });

            //------------- Wizard with progressbar -------------//
            //init first wizard
            $('#wizard1').bootstrapWizard({
                tabClass: 'bwizard-steps',
                nextSelector: 'ul.pager li.next',
                previousSelector: 'ul.pager li.previous',
                firstSelector: null,
                lastSelector: null,
                onTabShow: function( tab, navigation, index ) {
                    tab.prevAll().addClass('completed');
                    tab.nextAll().removeClass('completed');
                    var $total = navigation.find('li').length;
                    var $current = index+1;
                    var $percent = ($current/$total) * 100;
                    $('#wizard1').find('.progress-bar').css({width:$percent+'%'});
                    // If it's the last tab then hide the last button and show the finish instead
                    if($current >= $total) {
                        $('#wizard1').find('.pager .next').hide();
                        $('#wizard1').find('.pager .finish').show();
                        $('#wizard1').find('.pager .finish').removeClass('disabled');
                    } else {
                        $('#wizard1').find('.pager .next').show();
                        $('#wizard1').find('.pager .finish').hide();
                    }
                }
            });

            //wizard is finish
            $('#wizard1 .finish').click(function() {
                //show message
            });

        });

    }]);



app.controller("GalleryController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
//MAGNIFIC POPUP
        $(function () {
            $('.show-image').magnificPopup({type: 'image'});
        });
    }]);



app.controller("GridOptionsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("IconsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("LineaArrowsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("LineaBasicController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("LineaEcommerceController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("LineaElaborationController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("LockscreenController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(function () {

        });
    }]);



app.controller("LoginController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

    }]);



app.controller("MailComposeController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        jQuery(document).ready(function () {
            // HTML5 WYSIWYG Editor
            jQuery('#wysiwyg').wysihtml5({color: true, html: true});
        });
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("ModelsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("MorrisController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        !function($) {
            "use strict";
            $(function () {

                //one line chart
                Morris.Line({
                    element: 'morris-one-line-chart',
                    data: [
                        {year: '2008', value: 5},
                        {year: '2009', value: 10},
                        {year: '2010', value: 8},
                        {year: '2011', value: 22},
                        {year: '2012', value: 8},
                        {year: '2014', value: 10},
                        {year: '2015', value: 5}
                    ],
                    xkey: 'year',
                    ykeys: ['value'],
                    resize: true,
                    lineWidth: 4,
                    gridTextColor: '#949ba2',
                    labels: ['Value'],
                    lineColors: ['#149957'],
                    pointSize: 5
                });

                //line chart
                Morris.Line({
                    element: 'morris-line-chart',
                    data: [{ y: '2006', a: 100, b: 90 },
                        { y: '2007', a: 75, b: 65 },
                        { y: '2008', a: 50, b: 40 },
                        { y: '2009', a: 75, b: 65 },
                        { y: '2010', a: 50, b: 40 },
                        { y: '2011', a: 75, b: 65 },
                        { y: '2012', a: 100, b: 90 } ],
                    xkey: 'y',
                    ykeys: ['a', 'b'],
                    labels: ['Series A', 'Series B'],
                    hideHover: 'auto',
                    resize: true,
                    gridTextColor: '#949ba2',
                    lineColors: ['#3ec280','#149957']
                });

                //bar charts
                Morris.Bar({
                    element: 'morris-bar-chart',
                    data: [{ y: '2006', a: 60, b: 50 },
                        { y: '2007', a: 75, b: 65 },
                        { y: '2008', a: 50, b: 40 },
                        { y: '2009', a: 75, b: 65 },
                        { y: '2010', a: 50, b: 40 },
                        { y: '2011', a: 75, b: 65 },
                        { y: '2012', a: 100, b: 90 } ],
                    xkey: 'y',
                    ykeys: ['a', 'b'],
                    labels: ['Series A', 'Series B'],
                    hideHover: 'auto',
                    resize: true,
                    gridTextColor: '#949ba2',
                    barColors: ['#149957', '#3ec280']

                });
            });

        }(window.jQuery);

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("OrdersController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        vm.orderData = [
            {
                id: '0001',
                purchage_date: '03/11/2015',
                client_name: 'Addison Nichols',
                amount: '515.20',
                quantity: '547',
                shipment: '04/10/2015',
                status: 'Standby'
            },
            {
                id: '0002',
                purchage_date: '05/11/2015',
                client_name: 'Albert Watkins',
                amount: '22.30',
                quantity: '122',
                shipment: '06/10/2015',
                status: 'Paid'
            },
            {
                id: '0003',
                purchage_date: '07/09/2015',
                client_name: 'Johnny Fernandez',
                amount: '31.4',
                quantity: '68',
                shipment: '28/09/2015',
                status: 'Standby'
            },
            {
                id: '0011',
                purchage_date: '19/09/2015',
                client_name: 'Gilbert Edwards',
                amount: '5115.12',
                quantity: '51',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0012',
                purchage_date: '20/09/2015',
                client_name: 'Norman Hill',
                amount: '5124.13',
                quantity: '41',
                shipment: '-',
                status: 'Shipped'
            },
            {
                id: '0013',
                purchage_date: '22/09/2015',
                client_name: 'Samantha Murphy',
                amount: '513.214',
                quantity: '54',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0014',
                purchage_date: '30/09/2015',
                client_name: 'Nora Lambert',
                amount: '147.15',
                quantity: '65',
                shipment: '23/11/2015',
                status: 'Paid'
            },
            {
                id: '0015',
                purchage_date: '29/07/2015',
                client_name: 'Shelly Robertson',
                amount: '15.016',
                quantity: '12',
                shipment: '-',
                status: 'Canceled'
            },
            {
                id: '0016',
                purchage_date: '22/07/2015',
                client_name: 'Everett Garcia',
                amount: '188.19',
                quantity: '65',
                shipment: '029/11/2015',
                status: 'Paid'
            }
        ];



        $scope.whatClassIsIt = function (someValue) {
            if (someValue == "Paid")
                return "label-success"
            else if (someValue == "Shipped")
                return "label-purple";
            else if (someValue == "Rejected")
                return "label-danger";
            else if (someValue == "Canceled")
                return "label-inverse";
            else if (someValue == "Standby")
                return "label-info";
        }

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);



app.controller("PieChartsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(function () {
            $('.easy-pie-chart-1').easyPieChart({
                easing: 'easeOutBounce',
                barColor: '#17bb6a',
                lineWidth: 3,
                animate: 1000,
                lineCap: 'square',
                trackColor: '#e5e5e5',
                onStep: function (from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent));
                }
            });
            $('.easy-pie-chart-2').easyPieChart({
                easing: 'easeOutBounce',
                barColor: '#17bb6a',
                lineWidth: 3,
                trackColor: false,
                lineCap: 'butt',
                scaleColor: false,
                onStep: function (from, to, percent) {
                    $(this.el).find('.percent').text(Math.round(percent));
                }
            });
        });

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("ProductsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        vm.orderData = [
            {
                id: '0001',
                name: 'Product 1',
                description: 'Description for Product',
                price: '12.20',
                quantity: '233',
                status: 'Stock',
                added: '04/10/2015'
            },
            {
                id: '0002',
                name: 'Product 2',
                description: 'Description for Product',
                price: '13.20',
                quantity: '245',
                status: 'Stock',
                added: '04/10/2015'
            },
            {
                id: '0003',
                name: 'Product 3',
                description: 'Description for Product',
                price: '14.20',
                quantity: '210',
                status: 'Removed',
                added: '04/10/2015'
            },
            {
                id: '0004',
                name: 'Product 4',
                description: 'Description for Product',
                price: '17.20',
                quantity: '310',
                status: 'Out of Stock',
                added: '04/10/2015'
            },
            {
                id: '0005',
                name: 'Product 5',
                description: 'Description for Product',
                price: '11.20',
                quantity: '110',
                status: 'Removed',
                added: '04/10/2015'
            },
            {
                id: '0006',
                name: 'Product 6',
                description: 'Description for Product',
                price: '14.80',
                quantity: '220',
                status: 'Stock',
                added: '04/10/2015'
            },
            {
                id: '0007',
                name: 'Product 7',
                description: 'Description for Product',
                price: '17.50',
                quantity: '200',
                status: 'Removed',
                added: '04/10/2015'
            },
            {
                id: '0008',
                name: 'Product 8',
                description: 'Description for Product',
                price: '14.50',
                quantity: '109',
                status: 'Out of Stock',
                added: '04/10/2015'
            },
            {
                id: '0009',
                name: 'Product 9',
                description: 'Description for Product',
                price: '16.50',
                quantity: '185',
                status: 'Removed',
                added: '04/10/2015'
            },
        ];



        $scope.whatClassIsIt = function (someValue) {
            if (someValue == "Stock")
                return "label-success"
            else if (someValue == "Removed")
                return "label-danger";
            else if (someValue == "Out of Stock")
                return "label-warning";
        }

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);



app.controller("ProgressBarController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("RangeSliderController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $("#range_01").ionRangeSlider();

        $("#range_02").ionRangeSlider({
            min: 100,
            max: 1000,
            from: 550
        });
        $("#range_03").ionRangeSlider({
            type: "double",
            grid: true,
            min: 0,
            max: 1000,
            from: 200,
            to: 800,
            prefix: "$"
        });
        $("#range_04").ionRangeSlider({
            type: "double",
            grid: true,
            min: -1000,
            max: 1000,
            from: -500,
            to: 500
        });
        $("#range_16").ionRangeSlider({
            grid: true,
            min: 18,
            max: 70,
            from: 30,
            prefix: "Age ",
            max_postfix: "+"
        });
        $("#range_18").ionRangeSlider({
            type: "double",
            min: 100,
            max: 200,
            from: 145,
            to: 155,
            prefix: "Weight: ",
            postfix: " million pounds",
            decorate_both: false
        });
        $("#range_22").ionRangeSlider({
            type: "double",
            min: 1000,
            max: 2000,
            from: 1200,
            to: 1800,
            hide_min_max: true,
            hide_from_to: true,
            grid: true
        });


    }]);


app.controller("TabPanelsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        (function ($) {

            $(function () {
                $('.panel')
                    .on('panel:toggle', function () {
                        var $this,
                            direction;

                        $this = $(this);
                        direction = $this.hasClass('panel-collapsed') ? 'Down' : 'Up';

                        $this.find('.panel-body, .panel-footer')[ 'slide' + direction ](200, function () {
                            $this[ (direction === 'Up' ? 'add' : 'remove') + 'Class' ]('panel-collapsed')
                        });
                    })
                    .on('panel:dismiss', function () {
                        var $this = $(this);

                        if (!!($this.parent('div').attr('class') || '').match(/col-(xs|sm|md|lg)/g) && $this.siblings().length === 0) {
                            $row = $this.closest('.row');
                            $this.parent('div').remove();
                            if ($row.children().length === 0) {
                                $row.remove();
                            }
                        } else {
                            $this.remove();
                        }
                    })
                    .on('click', '[data-panel-toggle]', function (e) {
                        e.preventDefault();
                        $(this).closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '[data-panel-dismiss]', function (e) {
                        e.preventDefault();
                        $(this).closest('.panel').trigger('panel:dismiss');
                    })
                    /* Deprecated */
                    .on('click', '.panel-actions a.fa-caret-up', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this
                            .removeClass('fa-caret-up')
                            .addClass('fa-caret-down');

                        $this.closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '.panel-actions a.fa-caret-down', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this
                            .removeClass('fa-caret-down')
                            .addClass('fa-caret-up');

                        $this.closest('.panel').trigger('panel:toggle');
                    })
                    .on('click', '.panel-actions a.fa-times', function (e) {
                        e.preventDefault();
                        var $this = $(this);

                        $this.closest('.panel').trigger('panel:dismiss');
                    });
            });

        })(jQuery);
    }]);



app.controller("TableBasicController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        vm.tableData = [
            {
                id:'1',
                fname: 'Karen',
                lname: 'Martin',
                username: '@karen'
            },
            {
                id:'2',
                fname: 'Jame',
                lname: 'Smith',
                username: '@jame'
            },
            {
                id:'3',
                fname: 'Sarah',
                lname: 'Garcia',
                username: '@sarah'
            },

        ];


        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("DataTablesController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

    }]);



app.controller("TableEditableController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("TableJSGridController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("TableResponsiveController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        vm.tableData = [
            {
                title: 'Avatar',
                link:'http://en.wikipedia.org/wiki/Avatar_(2009_film)',
                rank: '1',
                year: '11/2009',
                rating: '83',
                gross : '2.7B'
            },
            {
                title:'Titanic',
                link:'http://en.wikipedia.org/wiki/Titanic_(1997_film)',
                rank: '2',
                year: '12/1997',
                rating: '88',
                gross : '2.1B'
            },
            {
                title:'The Avengers',
                link:'http://en.wikipedia.org/wiki/The_Avengers_(2012_film)',
                rank: '3',
                year: '3/2012',
                rating: '92',
                gross : '1.5B'
            },
            {
                title:'Harry Potter and the Deathly Hallows-Part 2',
                link:'http://en.wikipedia.org/wiki/Harry_Potter_and_the_Deathly_Hallows_%E2%80%93_Part_2',
                rank: '4',
                year: '2011',
                rating: '96',
                gross : '1.3B'
            },
            {
                title:'Frozen',
                link:'http://en.wikipedia.org/wiki/Frozen_(2013_film)',
                rank: '5',
                year: '2013',
                rating: '89',
                gross : '1.2B'
            },
            {
                title:'Iron Man 3',
                link:'http://en.wikipedia.org/wiki/Iron_Man_3',
                rank: '3',
                year: '3/2012',
                rating: '92',
                gross : '1.5B'
            },
            {
                title:'Transformers: Dark of the Moon',
                link:'http://en.wikipedia.org/wiki/Transformers:_Dark_of_the_Moon',
                rank: '7',
                year: '2011',
                rating: '36',
                gross : '1.1B'
            },
            {
                title:'The Lord of the Rings: The Return of the King',
                link:'http://en.wikipedia.org/wiki/The_Lord_of_the_Rings:_The_Return_of_the_King',
                rank: '8',
                year: '2003',
                rating: '95',
                gross : '1.1B'
            },
            {
                title:'Skyfall',
                link:'http://en.wikipedia.org/wiki/Skyfall',
                rank: '9',
                year: '2012',
                rating: '92',
                gross : '1.1B'
            },
            {
                title:'Transformers: Age of Extinction',
                link:'http://en.wikipedia.org/wiki/Transformers:_Age_of_Extinction',
                rank: '10',
                year: '2014',
                rating: '18',
                gross : '1.0B'
            },

        ];

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("ThemifyIconsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("TooltipController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $(function() {
            //tooltip
            $(function() {
                $('[data-toggle="tooltip"]').tooltip()
            })


            //Popover
            $(function() {
                $('[data-toggle="popover"]').popover()
            })

            // menu

            $('header select').change(function() {
                var goTo = $(this).val();
                var section = $('#'+goTo);
                var offset = section.offset().top;
                $('html, body').scrollTop(offset);
            });

            // usual tooltips

            $('.tooltip').not('#welcome .tooltip').tooltipster();

            $('#welcome .tooltip').tooltipster({
                theme: 'tooltipster-light'
            });

            // demos

            $('#demo-default').tooltipster({});



            $('#demo-html').tooltipster({
                // setting a same value to minWidth and maxWidth will result in a fixed width
                maxWidth: 400,
                side: 'right'
            });

            $('#demo-theme').tooltipster({
                animation: 'grow',
                theme: 'tooltipster-pink'
            });



            $('#demo-events').tooltipster({
                trigger: 'click'
            });

            /*
             // for testing purposes
             var instance = $('#demo-events').tooltipster('instance');
             instance.on('reposition', function(){
             alert('hey');
             });
             */

            $(window).keypress(function() {
                $('#demo-events').tooltipster('hide');
            });

            $('#demo-interact').tooltipster({
                contentAsHTML: true,
                interactive: true
            });

            $('#demo-touch').tooltipster({
                trigger: 'click',
                functionBefore: function(instance, helper){
                    if (helper.event.type == 'click') {
                        instance.content('You opened me with a regular mouse click :)');
                    }
                    else {
                        instance.content('You opened me by a tap on the screen :)');
                    }
                }
            });
            $('#demo-imagemaparea').tooltipster();

            $('#demo-multiple').tooltipster({
                animation: 'swing',
                content: 'North',
                side: 'top',
                theme: 'tooltipster-borderless'
            });
            $('#demo-multiple').tooltipster({
                content: 'East',
                multiple: true,
                side: 'right',
                theme: 'tooltipster-punk'
            });
            $('#demo-multiple').tooltipster({
                animation: 'grow',
                content: 'South',
                multiple: true,
                side: 'bottom',
                theme: 'tooltipster-light'
            });
            $('#demo-multiple').tooltipster({
                animation: 'fall',
                content: 'West',
                multiple: true,
                side: 'left',
                theme: 'tooltipster-shadow'
            });

            var complexInterval;

            $('#demo-complex')
                .tooltipster({
                    trackerInterval: 15,
                    trackOrigin: true,
                    trigger: 'custom'
                })
                .click(function(){

                    var $this = $(this);

                    if($this.hasClass('complex')){

                        $this
                            .removeClass('complex')
                            .tooltipster('hide')
                            .css({
                                left: '',
                                top: ''
                            });

                        clearInterval(complexInterval);
                    }
                    else {

                        var bcr = this.getBoundingClientRect(),
                            odd = true;

                        $this
                            .addClass('complex')
                            .css({
                                left: bcr.left + 'px',
                                top: bcr.top + 'px'
                            })
                            .tooltipster('show');

                        complexInterval = setInterval(function(){

                            var offset = odd ? 200 : 0;

                            $this.css({
                                left: bcr.left + offset
                            });

                            odd = !odd;
                        }, 2000);
                    }
                });

            $('#demo-position').tooltipster({
                // 8 extra pixels for the arrow to overflow the grid
                functionPosition: function(instance, helper, data){

                    // this function is pretty dumb and does not check if there is actually
                    // enough space available around the tooltip to move it, it just makes it
                    // snap to the grid. You might want to do something smarter in your app!

                    var gridBcr = $('#demo-position-grid')[0].getBoundingClientRect(),
                        arrowSize = parseInt($(helper.tooltipClone).find('.tooltipster-box').css('margin-left'));

                    // override these
                    data.coord = {
                        // move the tooltip so the arrow overflows the grid
                        left: gridBcr.left - arrowSize,
                        top: gridBcr.top
                    };

                    return data;
                },
                maxWidth: 228,
                side: ['right']
            });

            $('#demo-plugin').tooltipster({
                plugins: ['follower']
            });

            // nested demo
            $('#nesting').tooltipster({
                content: $('<span>Hover me too!</span>'),
                functionReady: function(instance){

                    // the nested tooltip must be initialized once the first
                    // tooltip is open, that's why we do this inside
                    // functionReady()
                    instance.content().tooltipster({
                        content: 'I am a nested tooltip!',
                        distance: 0
                    });
                },
                interactive: true
            });

            // grouped demo
            $('.tooltip_slow').tooltipster({
                animationDuration: 1000,
                delay: 1000
            });

            $.tooltipster.group('tooltip_group');

            // themes

            $('.tooltipster-light-preview').tooltipster({
                theme: 'tooltipster-light'
            });
            $('.tooltipster-borderless-preview').tooltipster({
                theme: 'tooltipster-borderless'
            });
            $('.tooltipster-punk-preview').tooltipster({
                theme: 'tooltipster-punk'
            });
            $('.tooltipster-noir-preview').tooltipster({
                theme: 'tooltipster-noir'
            });
            $('.tooltipster-shadow-preview').tooltipster({
                theme: 'tooltipster-shadow'
            });

        });
    }]);


app.controller("TreeViewController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);




app.controller("TypographyController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);



app.controller("VectorMapsController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;

        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });

        //------------- Last sales locations -------------//
        $(function () {
            $('#world-map').vectorMap({
                map: 'world_mill_en',
                scaleColors: ['#666', '#29b6d8'],
                normalizeFunction: 'polynomial',
                hoverOpacity: 0.7,
                hoverColor: false,
                focusOn: {
                    x: 0.5,
                    y: 0.5,
                    scale: 1.0
                },
                zoomMin: 0.85,
                markerStyle: {
                    initial: {
                        fill: '#fff',
                        stroke: '#fff',
                        color: '#ffffff'
                    }
                },
                backgroundColor: '#fff',
                regionStyle: {
                    initial: {
                        fill: '#8BC34A',
                        "fill-opacity": 1,
                        stroke: '#87c2e0',
                        "stroke-width": 0,
                        "stroke-opacity": 0
                    },
                    hover: {
                        "fill-opacity": 0.8
                    },
                    selected: {
                        fill: 'yellow'
                    }
                },
                markers: [
                    //http://www.latlong.net/
                    {latLng: [51.507351, -0.127758], name: 'London'},
                    {latLng: [41.385064, 2.173403], name: 'Barcelona'},
                    {latLng: [40.712784, -74.005941], name: 'New York'},
                    {latLng: [-22.911632, -43.188286], name: 'Rio De Janeiro'},
                    {latLng: [49.282729, -123.120738], name: 'Vancuver'},
                    {latLng: [35.689487, 139.691706], name: 'Tokio'},
                    {latLng: [55.755826, 37.617300], name: 'Moskva'},
                    {latLng: [43.214050, 27.914733], name: 'Varna'},
                    {latLng: [30.044420, 31.235712], name: 'Cairo'}
                ]
            });


            var barData = {
                labels: ["January", "February", "March", "April", "May", "June", "July"],
                datasets: [
                    {
                        label: "My First dataset",
                        fillColor: "rgba(140, 192, 250,0.5)",
                        strokeColor: "rgba(140, 192, 250,0.8)",
                        highlightFill: "rgba(140, 192, 250,0.75)",
                        highlightStroke: "rgba(140, 192, 250,1)",
                        data: [65, 59, 80, 81, 56, 55, 40]
                    },
                    {
                        label: "My Second dataset",
                        fillColor: "rgba(14, 150, 236,0.5)",
                        strokeColor: "rgba(14, 150, 236,0.8)",
                        highlightFill: "rgba(14, 150, 236,0.75)",
                        highlightStroke: "rgba(14, 150, 236,1)",
                        data: [28, 48, 40, 19, 86, 27, 90]
                    }
                ]
            };

            var barOptions = {
                scaleBeginAtZero: true,
                scaleShowGridLines: true,
                scaleGridLineColor: "rgba(0,0,0,.05)",
                scaleGridLineWidth: 1,
                barShowStroke: true,
                barStrokeWidth: 2,
                barValueSpacing: 5,
                barDatasetSpacing: 1,
                responsive: true
            };


            //var ctx = document.getElementById("barChart").getContext("2d");
            //var myNewChart = new Chart(ctx).Bar(barData, barOptions);

        });
    }]);



app.controller("WeatherIconController", ['$rootScope', '$scope', '$state', '$location', 'dashboardService', 'Flash',
    function ($rootScope, $scope, $state, $location, dashboardService, Flash) {
        var vm = this;
        $('.panel-action-dismiss').click(function(){
            $(this).parent().parent().parent('.panel').parent().remove();
        });
    }]);

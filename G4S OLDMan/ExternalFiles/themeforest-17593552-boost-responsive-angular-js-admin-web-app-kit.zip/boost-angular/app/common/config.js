﻿
var appConfig = {
    title: "Corporate Directory",
    lang: "en",
    dateFormat: "mm/dd/yy",
    apiBase: 'http://192.168.168.213:3000/api/'
};